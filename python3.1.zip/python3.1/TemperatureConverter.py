def fahrenheit_to_celsius(fahrenheit):
#Converts temperature from Fahrenheit to Celsius.
    return (fahrenheit - 32) * 5.0/9.0

def celsius_to_fahrenheit(celsius):
#Converts temperature from Celsius to Fahrenheit.
    return (celsius * 9.0/5.0) + 32

def main():
#Main function to interact with the user.
    while True:
        print("Temperature Converter")
        print("1. Fahrenheit to Celsius")
        print("2. Celsius to Fahrenheit")
        print("3. Exit")
        choice = input("Please choose an option (1, 2, or 3): ")

        if choice == '1':
            fahrenheit = float(input("Enter temperature in Fahrenheit: "))
            celsius = fahrenheit_to_celsius(fahrenheit)
            print(f"{fahrenheit} Fahrenheit is equal to {celsius:.2f} Celsius.")
        
        elif choice == '2':
            celsius = float(input("Enter temperature in Celsius: "))
            fahrenheit = celsius_to_fahrenheit(celsius)
            print(f"{celsius} Celsius is equal to {fahrenheit:.2f} Fahrenheit.")
        
        elif choice == '3':
            print("Exiting the program.")
            break
        
        else:
            print("Invalid choice. Please select 1, 2, or 3.")

        print()

if __name__ == "__main__":
    main()
